---
tags: [tema, archivo, biblioteca, personajes, funciones]
---

# Funciones del archivo: quién hace qué

**Problema:** Alec, Odile, Yokany y la propia Yen cumplen la misma función (guardar y mover pruebas). Si no se diferencian, tres personajes se vuelven uno.

| Personaje | Verbo | Escena que solo ella/él puede hacer |
|---|---|---|
| **Alec** | **Guardar** | Duplica y esconde en el momento de la redada; sabe qué prueba pesa. Su fe en la evidencia se rompe. |
| **Odile** | **Restaurar** | Recupera lo que el archivo oficial iba a incinerar; detecta falsificaciones por la mancha, la humedad, el corte. Es la única que puede "leer" papel dañado. |
| **Yokany** | **Distribuir / traducir** | Mueve la verdad por redes civiles (radios comunitarias, tablones, comunidad sorda) y la vuelve comprensible. Es quien enseña a Alec que la evidencia necesita circular. |
| **Yen** | **Analizar** | Lee huellas en papel y separa lo que sabe de lo que supone (hoja de dos columnas). Es la mente del archivo, no su custodia. |
| **Lena** | **Organizar** | Convierte todo lo anterior en infraestructura (rutas, llaves, horarios). |

**Regla de uso:** si una escena puede hacerla cualquiera de los cinco, se reescribe para que solo la pueda hacer uno, o se corta.

**Tema común:** guardar sin distribuir es museo; distribuir sin restaurar es rumor; restaurar sin analizar es nostalgia.
