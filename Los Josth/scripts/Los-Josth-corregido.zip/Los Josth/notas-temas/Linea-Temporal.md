---
tags: [tema, cronología, timeline, historia]
---

# Línea Temporal

**Documento:** Cronología completa de eventos  
**Período:** Desde 579 DT hasta 599 DT

## Pre-589 DT

### 579–588 DT: [[Represion-Dictadura]]
- Período de represión oficial
- [[Rish]] participa como joven cómplice (20 años en 579) — **la fecha sí cuadra**; se elimina el comentario de que "no participó"
- [[Bastean]] participa y luego deserta
- Represores forman red de complicidad

### 586 DT: Operación Tierra 5 ([[Derat]])
- Barrido represivo en el poblado minero
- Muere la hija de [[Bastean]]
- Se incauta y "pierde" el arma ceremonial
- Responsables y cargos en [Lista-40](../tramas/Lista-40.md)

### 588–589 DT: Post-Represión
- Dictadura oficialmente "termina"
- No hay transición de justicia real
- Represores permanecen en poder o se esconden
- [[SATT]] consolida autoridad

### 588 DT: Revolución en [[Teknara]]
- Líder revolucionario es capturado
- Arma ceremonial es confiscada por [[SATT]]
- Arma desaparece del inventario

---

## 589 DT: Volumen 1 — [[Arco-Novata]]

- **Primavera/Verano:** [[Yen]] entra a [[SATT]] (25 años)
- Primer caso Vath (contrabando)
- Múltiples casos episódicos
- Muerte de [[Herday]] por [[Bastean]] (n.º 37 de la lista; [[Kluar]], n.º 12, murió antes del cap. 1 y se atribuyó a un accidente)
- **Fin:** [[Yen]] + [[Lena]] se mudan juntas

---

## 590–591 DT: Volumen 2 — [[Arco-Bastean]]

- **Investigación de asesinatos rituales**
- Descubrimiento de patrón: represores siendo asesinados
- Pista de [[Daga-Navarí]] y arma histórica
- Persecución a [[Teknara]] (Bastean escapa)
- Hospital: [[Yen]] se cura en semana
- Confrontación final; captura de [[Bastean]]
- **Muerte en custodia**: suicidio (3 disparos)
- **Fin:** Verdad borrada; [[Rish]] es degradado

---

## 592–594 DT: Volumen 3 — [[Arco-Romance|Contrabando + Romance]]

- **Velocidad:** Más lenta; establece normalidad
- [[Rish]] es agente de campo (mismo nivel que [[Yen]])
- Red de contrabando (subsídio de[[Arco-Bastean]])
- Múltiples casos episódicos mundo-building
- **La Playa (593 DT):** [[Rish]] confesa amor a [[Yen]]; comienza relación 5 años
- Noche con estrellas en piscina

---

## 595–596 DT: Volumen 4 — [[Arco-Navar|Regreso a Navar]]

- **Muerte del padre de [[Yen]]**
- [[Yen]] regresa a tierra natal
- Confrontación con familia
- Quiebre emocional; relación no se repara
- **Fe religiosa se fractura**
- Otros eventos no aún especificados (editorial menciona "debe haber pasado algo entre este y el arco de la isla")

---

## 597 DT: Volumen 5 — [[Arco-Isla]]

- **Investigación de familia: tráfico de órganos**
- Localización: isla
- Familia de traficantes (prácticamente caníbales)
- Captura de equipo; [[Yen]] es capturada
- **[[Yen]] pierde brazo izquierdo** (amputación)
- Escape; [[Rish]] herido; rescate
- **Playa de isla:** [[Yen]] en alucinaciones; estrangula a [[Rish]]
- [[Lena]] llega en barca; ve a [[Yen]] + cuerpo de [[Rish]]; asume muerte natural
- **Yen entra en estado catatónico**

---

## 598–599 DT: Volumen 6 — [[Arco-Final|Depresión y Caída]]

- Casi dos años tras la isla (Pazyn 597 → Ovryn 599): [[Yen]] renuncia a [[SATT]] (598)
- Vive con [[Lena]]; Lena la cuida como enfermera
- Intento de suicidio #1: [[Lena]] lo impide
- **[[Lena]] forma [[Rebelion]]**; debe abandonar a [[Yen]]
- [[Yen]] entra en suicidio pasivo: deja de comer
- Cabello crece lentamente (1 año ≈ crecimiento visible)
- [[Yen]] camina sola a [[Torre-Central-SATT]] (noche previa a su destrucción)
- **Se resbala y cae**
- Visión del espectro/deidad; ve su vida completa
- Cuerpo cae 280 pisos
- **Desintegrado en portal**; sin tumba

---

## 599 DT: Post-Volumen 6

- **[[Rebelion]] toma central de [[SATT]]**
- [[SATT]] es demolida
- **Fuerzas anti-rebelión contraatacan**
- [[Lena]]: ejecutada como traidora; deja mensaje a [[Yen]]
- [[Zhan]]: destino incierto
- [[Alec]]: deserción tranquila; vive en tierra natal con familia
- **[[SATT]] resurge** en forma diferente (aislacionismo)
- Nuevo régimen toma poder (similar a represión original)

---

## Línea de Edad de Personajes

| Personaje | 589 DT | 593 DT | 597 DT | 599 DT |
|-----------|--------|--------|--------|--------|
| [[Yen]] | 25 | 29 | 33 | 35 |
| [[Lena]] | 29 | 33 | 37 | 39 |
| [[Rish]] | 30 | 34 | 38 (muere en 597) | — |
| [[Zhan]] | 32–34 | 36–38 | 40–42 | 42–44 |
| [[Herday]] | 45–55 | — (muere en 589) | — | — |

---

## Temas Recurrentes por Período

| Período | Tema Emocional | Tema Institucional |
|---------|---|---|
| Vol. 1 (589) | Pertenencia | Iniciación |
| Vol. 2 (590–91) | Corrupción | Encubrimiento |
| Vol. 3 (592–94) | Amor/Esperanza | Falsa estabilidad |
| Vol. 4 (595–96) | Quiebre | Regreso forzado |
| Vol. 5 (597) | Trauma | Explotación extrema |
| Vol. 6 (598–99) | Depresión | Colapso/Resurección |

---

## Símbolo General: 10 Años
- [[Yen]] entra Vol. 1 (589)
- [[Yen]] cae Vol. 6 (599)
- Exactamente 10 años
- Cabello naváreo tarda 10 años en crecer (cuando abandonó familia)
- Subraya ciclicidad: donde empezó, donde termina
