---
tags: [tema, registro, cambios, canon]
---

# Registro de cambios — 2026-10-02

## Decisiones tomadas (propuestas, revisables)

1. **Portal:** el anillo se cierra 7 → 1. Návar (6) queda a dos saltos de Amitia (6 → 7 → 1) vía la estación de tránsito SATT en Terra; cada salto = 4 dacmos. Se mantiene la numeración y la geopolítica del ensayo (Derat contigua a Khorza y Návar).
2. **Seol / Saol:** Seol = alma; Saol = lugar de descanso. Hay que invertirlo en la Cosmología.
3. **Cronología:** isla Pazyn 597 → caída Ovryn 599 (casi dos años). Primer intento: fin de 598.
4. **Calendario:** 10 semanas de 5 días (no 5 de 10).
5. **Lista-40:** el orden es causal, no jerárquico. Rish n.º 38 por su delación.
6. **Vath:** Rish no lo libera; aprovecha la fuga. Plantado: "se parece lo suficiente".
7. **Navarí:** solo para el culto. Daga navárea.
8. **Capítulos:** el piloto pasa a 01; el Domo a 02; el viejo 02 (medios) queda en `_fusionar/` para fundirlo en el 03.

## Archivos tocados

- `capitulos/La novata/01.md` — nuevo (piloto Vath, normalizado, deducción reescrita, tunel aclarado, azotea, Espectro).
- `capitulos/La novata/02.md` — antes 01 (Domo); Riahim ya solo sospecha.
- `capitulos/La novata/_fusionar/02-medios-fusionar-en-03.md` — antes 02.
- `capitulos/00 prologo.md` — "un año atrás", "su vida", "casi dos años", "ocho dacmos / dos universos", "seol".
- `notas-temas/Canon.md`, `Linea-Temporal.md`, `Plan-Editorial.md`, `Plantas-y-Cosechas.md`.
- `notas-temas/Funciones-del-Archivo.md` — nuevo.
- `tramas/Lista-40.md` — orden causal; renombres (Petre Aldous, Joren Wale).
- `Transtierra.md` — 600 → 599; "Tierra 7 autoritaria" → Derat.

## Pendiente fuera del repo

- Diario de Earendil: años (589 → 588 en las dos primeras entradas), 7 → 4 dacmos, 17 saltos → 2, "tierra 13" → estación de Terra, Earendil → Yenriel.
- Cosmología: invertir Seol/Saol.

## Pendiente de escritura

- Pulir el piloto: quedan diálogos muy explícitos y preguntas retóricas (Plan-Editorial #13).
- Fusionar `_fusionar/02-medios...` en el cap. 03.
- Marcar plantas/cosechas de los volúmenes 2–6.
- Marcar la frase del Espectro en 02–07.
