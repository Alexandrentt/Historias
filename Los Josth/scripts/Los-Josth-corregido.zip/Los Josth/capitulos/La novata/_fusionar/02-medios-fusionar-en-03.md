---
title: "Capítulo 2: La verdadera secuela complicada"
epigraph: "Mañana será el gran día, por fin. Me gustaría decirte que estoy lista, y que sé exactamente qué voy a hacer cuando cruce, pero la verdad es que solo tengo una vaga idea. Trabajar, aprender rápido y no decepcionar a nadie. Suena simple. 
epigraph: "¿Por qué siento que no terminará así?"
synopsis: "Cuando un caaso industrial sacude las relaciones publicas, Yen comprende como funciona el enrevesado mundo de los medios de comunicacion."
status: "final"
wordCount: 857
created: "2026-03-30"
modified: "2026-03-30"
tags: ["cap02", "medios-de-comunicacion"]
---

# Capítulo 2: La verdadera secuela complicada

>Mañana será el gran día, por fin. Me gustaría decirte que estoy lista, y que sé exactamente qué voy a hacer cuando cruce, pero la verdad es que solo tengo una vaga idea. Trabajar, aprender rápido y no decepcionar a nadie. Suena simple. 
>¿Por qué siento que no terminará así?

Yen comenzaba a encajar, y eso era todo lo que necesitaba. El equipo sobrevolaba el bosque de Beosia en Teknara. La tranquilidad dentro de la cabina, pero afuera de sus audífonos parecía un postre que hacía tiempo no probaban. Sin duda, eso era lo que necesitaba.
Alec y Lena hablaban con las manos, y al verlos la sonrisa de Yen se desvaneció al instante, quizás aun no encajaba del todo. ¿Por qué será que aún no le enseñaban aquella lengua? ¿Aun no era digna de confianza para saber aquel lenguaje compartido? Pensar en eso la entristecía y enojaba a partes iguales, luego se dio cuenta de la estupidez que era sentirse así por una nimiedad, pero…
*¿Debería insistir en aquello?*
—Lena, ¿No dijiste que me enseñarías eso? —hizo un ademán con las manos, no estaba segura como llamarlo. Alec y Lena la veían confundidos —La lengua de señas.
—Ah, claro. ¿Eh... pues, te refieres a ahora?
—Sí —se levantó de su asiento al instante, se golpeó la cabeza con el techo de la cabina, no era un lugar muy espacioso. —Si tienes tiempo, claro.
—Relaja los músculos antes de que se te acalambren los que ni siquiera sabias que tenías.
Lena dio un bufido.
—No lo escuches —dijo alegremente. —Solo está jugado.
—Y bien...
—Si, verás, sé que dije que te enseñaría, pero creo que es mejor que lo haga Alec.
—Nah, tú te comprometiste —protestó él.
Yen le dio un vistazo a Alec, luego a Lena de nuevo.
—Él nos lo enseñó a Zhan y a mí.
—De verdad —preguntó Yen incrédula.
—Empezó por una estupidez.
—Ah, perdón. Creí que Yokany te caía bien.
—Ay, lo siento, no quise... —Lena volteó a ver a Yen, visiblemente confundida. Se aclaró la garganta —. El punto es que, él es el que mejor lo maneja, nosotros lo usamos para comunicarnos a plena vista, es más útil de lo que parece. No es que nos hayamos inventado nuestro propio código, es solo que casi nadie se molesta en aprender lengua de señas de alguna región especifica de Atharis.
El lárian de la aeronave comenzó a sonar. Zhan que era el que pilotaba descolgó y se lo lanzó a ellos. Alec lo atrapó, se aclaró la garganta e imitó la voz rasposa de Zhan.
—Nave C748 a bordo B4-12 cambio.
Silencio. 
—Afirmativo —susurró a Zhan por la distancia hacia el portal que medían los instrumentos de la aeronave, las coordenadas — (inserte coordenadas, tengo que revisar mejor el mapa de teknara.).
Silencio.
—Es Herday desde Amitia. 
Yen no había visto nunca que llamasen directamente al lárian a bordo, debía ser una emergencia si tuvieron que usar el sistema Lysis. Comunicarse a distancia entre Tierras era complicado. ¿Qué ameritaba el uso de tan costosa llamada?
—Está bien —contestó Alec. — Un segundo — le hizo una seña a lena para que le trajera algo para anotar. Lena sacó la libreta que tenía en su asiento al frente y Alec lo tomó —, está bien —.
Se levantó y dejó el lárian en el tablero de control junto a Zhan. De paso le susurró algo que Yen no alcanzó a oír.
—Parece que vamos a desviarnos un poco. Hubo una explosión o algo por el estilo, pero el chiste es que somos los únicos cerca. Así que ni modo. —Le puso la mano en el hombro a Yen —. Vas a tener que esperar. 
—¿Un caso?
Alec asintió con la cabeza.
—¿Pero, y el reporte de situación? —preguntó Yen —. No podemos empezar un caso sin que se nos notifique por escrito y esté asignado a nuestro equipo.
—Yen, relájate, esto pasa a menudo. Mas de lo que me gustaría. Pero no pasa nada. Mira, para compensarte el que no tengamos tiempo para la lengua de señas, si quieres, te puedo prestar el libro con el que lo aprendí
— Creí que Alec te había enseñado.
— Dije que era el que más sabía, no que fuese buen maestro. Hablando de eso. Qué se supone que tenemos que ver nosotros, cierto que la SATT se mete en todo, pero es muy irregular, hasta para nosotros.
—Eso estoy diciendo —afirmo Yen —.
Era un pequeño disco que fácilmente cabía en su palma. Ahora que por fin le habían dado su uniforme completo, gabardina incluida, podía cargarlos más fácilmente en un estuche que siempre cargaba encima.  
—Cuando logremos convencer a Herday de que nos asigne una aeronave propia entonces sí podrás cargar tantos de esos como quieras a las misiones. 
*Noticias en breve* —*. Amitia. La Procuraduría de Relaciones Exteriores extendió una carta para el magistrado Arik*Joid*, en la que tendrá que asistir a la citación por el juicio presente. Recordemos que*Joid*está vinculado a un caso de defraudación aduanera.*Estatale*...»*

---

## Continúa aquí...