RESPALDO DE MAPAS — HISTORIAS

Contenido:
- Cinco archivos .map.gz, uno por mapa.
- SHA256SUMS.json con SHA-256 del original y del comprimido.
- Los originales .map permanecen intactos fuera de este paquete.

Integridad:
Cada .map.gz se descomprimió durante la preparación y se comparó byte por byte
con su archivo .map original. Los hashes permiten verificar futuras copias.

GitHub:
Sube los cinco .map.gz y SHA256SUMS.json a:
mapas-azgaar/originales-comprimidos/

Restauración:
Descomprime cada archivo .map.gz una sola vez. El resultado debe tener el nombre
original terminado en .map. Luego carga ese .map en Azgaar Fantasy Map Generator.
No edites el contenido binario del .map manualmente.
