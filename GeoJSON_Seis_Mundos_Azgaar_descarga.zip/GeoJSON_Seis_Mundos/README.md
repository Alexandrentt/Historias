# GeoJSON vectorial de los seis mapas Azgaar

Este paquete fue generado a partir del ZIP `Historias_Mapas_Organizados_6_mundos.zip` aportado en la conversación.

## Contenido
Cada mundo tiene capas `rivers`, `routes`, `states`, `borders`, `lakes`, `ice` y `labels`, además de `manifest.json`.

## Alcance y limitaciones
Las geometrías se extrajeron de las rutas y polígonos vectoriales presentes en el SVG incrustado en cada `.map`, y se convirtieron de coordenadas del lienzo a longitud/latitud usando la configuración geográfica del propio mapa.

Esto **no equivale** a la exportación nativa de celdas de Azgaar: las capas de celdas/altura/biomas no se reconstruyen aquí como polígonos individuales. Algunas capas SVG (por ejemplo, lagos dibujados con referencias `<use>`) pueden aparecer vacías. Los archivos `.map` originales no se modificaron.

Para obtener las celdas nativas completas, abre cada `.map` en Azgaar y usa Export → GeoJSON → cells, routes, rivers, markers y zones.
